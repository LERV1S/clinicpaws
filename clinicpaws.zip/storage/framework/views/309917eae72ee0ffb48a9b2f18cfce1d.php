<div>
    <h1 class="text-2xl font-bold text-gray-900 dark:text-white mb-6">Manage Appointments</h1>

    <!-- Formulario para agregar o editar una cita -->
    <form wire:submit.prevent="saveAppointment" class="space-y-4">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <select wire:model="pet_id" class="input-field" required>
                <option value="">Select Pet</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($pet->id); ?>"><?php echo e($pet->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>

            <select wire:model="veterinarian_id" class="input-field" required>
                <option value="">Select Veterinarian</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $veterinarians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($vet->id); ?>"><?php echo e($vet->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>

            <input type="datetime-local" wire:model="appointment_date" class="input-field" required>
            <input type="text" wire:model="status" class="input-field" placeholder="Status" required>
            <textarea wire:model="notes" class="input-field" placeholder="Notes"></textarea>
        </div>
        <div class="flex justify-start mt-4">
            <button type="submit" class="cta-button"><?php echo e($selectedAppointmentId ? 'Update Appointment' : 'Add Appointment'); ?></button>
        </div>
    </form>

    <!-- Listado de citas -->
    <div class="mt-6">
        <ul class="space-y-4">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="bg-white dark:bg-gray-700 p-4 rounded-lg shadow flex justify-between items-center">
                    <div>
                        <p class="text-lg font-semibold">Pet: <?php echo e($appointment->pet->name); ?></p>
                        <p class="text-sm text-gray-600 dark:text-gray-400">
                            Veterinarian: <?php echo e($appointment->veterinarian->name); ?> - Date: <?php echo e($appointment->appointment_date); ?>

                        </p>
                    </div>
                    <div class="flex space-x-4">
                        <button wire:click="editAppointment(<?php echo e($appointment->id); ?>)" class="cta-button bg-yellow-500 hover:bg-yellow-600">Edit</button>
                        <button wire:click="deleteAppointment(<?php echo e($appointment->id); ?>)" class="cta-button bg-red-500 hover:bg-red-600">Delete</button>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\clinicpaws\resources\views/livewire/appointment-manager.blade.php ENDPATH**/ ?>