<div>
    <h1 class="text-2xl font-bold text-gray-900 dark:text-white mb-6">Manage Pets</h1>

    <!-- Formulario para agregar o editar una mascota -->
    <form wire:submit.prevent="savePet" class="space-y-4">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <select wire:model="owner_id" class="input-field" required>
                <option value="">Select Owner</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($owner->id); ?>"><?php echo e($owner->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <input type="text" wire:model="name" class="input-field" placeholder="Name" required>
            <input type="text" wire:model="species" class="input-field" placeholder="Species" required>
            <input type="text" wire:model="breed" class="input-field" placeholder="Breed">
            <input type="date" wire:model="birthdate" class="input-field" placeholder="Birthdate">
            <textarea wire:model="medical_conditions" class="input-field" placeholder="Medical Conditions"></textarea>
        </div>
        <div class="flex justify-start mt-4">
            <button type="submit" class="cta-button"><?php echo e($selectedPetId ? 'Update Pet' : 'Add Pet'); ?></button>
        </div>
    </form>

    <!-- Listado de mascotas -->
    <div class="mt-6">
        <ul class="space-y-4">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="bg-white dark:bg-gray-700 p-4 rounded-lg shadow flex justify-between items-center">
                    <div>
                        <p class="text-lg font-semibold"><?php echo e($pet->name); ?></p>
                        <p class="text-sm text-gray-600 dark:text-gray-400">
                            <?php echo e($pet->species); ?> - <?php echo e($pet->breed); ?> - Owner: <?php echo e($pet->owner->name); ?>

                        </p>
                    </div>
                    <div class="flex space-x-4">
                        <button wire:click="editPet(<?php echo e($pet->id); ?>)" class="cta-button bg-yellow-500 hover:bg-yellow-600">Edit</button>
                        <button wire:click="deletePet(<?php echo e($pet->id); ?>)" class="cta-button bg-red-500 hover:bg-red-600">Delete</button>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\clinicpaws\resources\views/livewire/pet-manager.blade.php ENDPATH**/ ?>