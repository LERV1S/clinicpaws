@extends('layouts.app')

@section('content')
    @livewire('prescription-manager')
@endsection
